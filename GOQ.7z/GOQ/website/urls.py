from django.urls import path
from . import views
from .views import message

urlpatterns = [
    path('',views.index, name="index"),
    path('contact/', views.contact, name="contact"),
    path('message/', message.as_view(), name="message"),
]